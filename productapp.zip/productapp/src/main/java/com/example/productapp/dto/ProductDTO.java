package com.example.productapp.dto;

import com.example.productapp.entity.Product;

public class ProductDTO {
    private Long id;
    private String name;
    private Double price;
    private String categoryName;

    public ProductDTO(Product product) {
        this.id = product.getId();
        this.name = product.getName();
        this.price = product.getPrice();
        this.categoryName = product.getCategory().getName();
    }

    // Getters only
}
