package com.example.productapp.controller;

import com.example.productapp.entity.*;
import com.example.productapp.dto.ProductDTO;
import com.example.productapp.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    @GetMapping
    public Page<ProductDTO> getAll(@RequestParam(defaultValue = "0") int page) {
        return productRepo.findAll(PageRequest.of(page, 5)).map(ProductDTO::new);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Product product) {
        if (product.getCategory() != null) {
            Optional<Category> category = categoryRepo.findById(product.getCategory().getId());
            if (category.isPresent()) {
                product.setCategory(category.get());
            } else {
                return ResponseEntity.badRequest().body("Invalid Category ID");
            }
        }
        return ResponseEntity.ok(productRepo.save(product));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> getById(@PathVariable Long id) {
        return productRepo.findById(id)
                .map(p -> ResponseEntity.ok(new ProductDTO(p)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Product updated) {
        return productRepo.findById(id).map(existing -> {
            existing.setName(updated.getName());
            existing.setPrice(updated.getPrice());
            if (updated.getCategory() != null) {
                categoryRepo.findById(updated.getCategory().getId()).ifPresent(existing::setCategory);
            }
            return ResponseEntity.ok(productRepo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        productRepo.deleteById(id);
        return ResponseEntity.ok().build();
    }
}

